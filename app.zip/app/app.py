
import wx



class MyForm(wx.Frame):
 
    #----------------------------------------------------------------------
    def __init__(self):
        wx.Frame.__init__(self, None, wx.ID_ANY, 
                          "Perk Ordering System")

      
        

        self.submitBttn=wx.Button(self, label='Submit', pos= (305,420),size = wx.Size(120,-1))

        

       
        

        self.panel_one = PanelOne(self)
        self.panel_two = PanelTwo(self)
        self.panel_three = PanelThree(self)
        self.panel_four = PanelFour(self)

        

        

        

        self.panel_two.Hide()
        self.panel_three.Hide()
        self.panel_four.Hide()

        

   
       

        

        

        
        
        self.sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer.Add(self.panel_one, 1, wx.EXPAND)
        self.sizer.Add(self.panel_two, 1, wx.EXPAND)
        self.sizer.Add(self.panel_three,1, wx.EXPAND)
        self.sizer.Add(self.panel_four,1, wx.EXPAND)
        self.SetSizer(self.sizer)

        self.SetClientSize(600,800)
        self.MaxImageSize=500
        self.Image = wx.StaticBitmap(self, bitmap=wx.Bitmap(self.MaxImageSize, self.MaxImageSize))
        Img = wx.Image('app\MicrosoftTeams-image.png', wx.BITMAP_TYPE_ANY)
        Img = Img.Scale(200,200,quality=wx.IMAGE_QUALITY_HIGH)
        self.Image.SetBitmap(wx.Bitmap(Img))
        
        color = wx.Colour(234,218,244)
        self.SetBackgroundColour(color)
        self.Image.SetPosition((200, 0))
        self.submitBttn.Bind(wx.EVT_BUTTON, self.onSwitchPanels)
        
        
        
        
        

    def onSwitchPanels(self, event):
        """"""
        if self.panel_one.IsShown():
            print('showing panel 2')
            self.submitBttn.Hide()
            self.panel_one.Hide()
            self.panel_two.Show()
        elif self.panel_two.IsShown():
            print('showing panel 3')
            self.panel_two.Hide()
            self.panel_three.Show()
        elif self.panel_three.IsShown():
            print('showing panel 4')
            self.panel_three.Hide()
            self.panel_four.Show()
        self.Layout()

    
    
   
        
        
        


class PanelOne(wx.Panel):
   
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        wx.Panel.__init__(self, parent=parent)
        self.LoginTitle = wx.StaticText(self, label = "User Authentication",  pos = (185,220),size=wx.DefaultSize)
        self.Username = wx.StaticText(self, wx.ID_ANY, 'Username', pos = (235, 288) )
        self.inputUsername = wx.TextCtrl(self, wx.ID_ANY, pos = (235,305))
        self.Password = wx.StaticText(self, wx.ID_ANY, 'Password', pos = (235, 348) )
        self.inputPassword = wx.TextCtrl(self, wx.ID_ANY, pos = (235,367))
        self.forgotBttn=wx.Button(self, label='Forgot Password', pos= (150,420), size = wx.Size(120,-1))
        
        font = wx.Font(20, family = wx.FONTFAMILY_DECORATIVE, style = wx.FONTSTYLE_SLANT, weight = wx.FONTWEIGHT_THIN, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        self.LoginTitle.SetFont(font)
        color = wx.Colour(234,218,244)
        self.LoginTitle.SetBackgroundColour(color)
        self.forgotBttn.Bind(wx.EVT_BUTTON, self.ShowDialog)
        

    def ShowDialog(self, event):

            
        self.dlg = wx.RichMessageDialog(parent=None, 
                                        message='Please contact administrator to reset your password', caption='Message box',
                                        style=wx.CANCEL|wx.CENTRE)
            
        self.dlg.ShowModal()
        
    

            

        

    
class PanelTwo(wx.Panel):
    
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        
        wx.Panel.__init__(self, parent=parent)
        font = wx.Font(20, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        
        self.CustomerInfo = wx.StaticText(self, label ='Customer Information', pos =(175,220))
        self.CustomerInfo.SetFont(font)
        self.nowRadioBttn = wx.RadioButton(self, label = 'New', pos = (215, 270))
        self.retRadioBttn = wx.RadioButton(self, label = 'Returning', pos = (315, 270))
        self.firstName = wx.StaticText(self, label ='First Name', pos =(215,330))
        self.inputFN = wx.TextCtrl(self, wx.ID_ANY, pos = (215,350),size = wx.Size(180,-1))
        self.lastName = wx.StaticText(self, label ='Last Name', pos =(215,390))
        self.inputLN = wx.TextCtrl(self, wx.ID_ANY, pos = (215,410),size = wx.Size(180,-1))
        self.Email = wx.StaticText(self, label ='Email', pos =(215,450))
        self.inputEmail = wx.TextCtrl(self, wx.ID_ANY, pos = (215,470),size = wx.Size(180,-1))
        self.phoneNum = wx.StaticText(self, label ='Phone Number', pos =(215,510))
        self.inputPN = wx.TextCtrl(self, wx.ID_ANY, pos = (215,530),size = wx.Size(180,-1))
        self.continueBttn= wx.Button(self, label = 'Continue', pos = (325,580))
        self.backBttn= wx.Button(self, label = 'Back', pos = (210,580))

        self.continueBttn.Bind(wx.EVT_BUTTON, MyForm.onSwitchPanels)

        

        
        



class PanelThree(wx.Panel):
    def __init__(self, parent):
        """Constructor"""
        
        wx.Panel.__init__(self, parent=parent)
        font = wx.Font(20, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)

        self.OrderDetails = wx.StaticText(self, label ='Order Details', pos =(225,220))
        self.OrderDetails.SetFont(font)
        self.basketLabel = wx.StaticText(self, label ='Select Your Basket', pos =(215,310))
        self.basketSelect = wx.Choice(self, choices=['A', 'B', 'C'], pos = (215,330), size = wx.Size(180,-1))
        self.giftLabel = wx.StaticText(self, label ='Extra Gift', pos =(215,370))
        self.extraGift = wx.Choice(self, choices=['A', 'B', 'C'], pos = (215,390), size = wx.Size(180,-1))
        self.colorLabel = wx.StaticText(self, label ='Color Theme', pos =(215,430))
        self.colorSelect = wx.Choice(self, choices=['A', 'B', 'C'], pos = (215,450), size = wx.Size(180,-1))
        self.quantityLabel = wx.StaticText(self, label ='Quantity', pos =(215,490))
        self.qSelect = wx.SpinCtrl(self, wx.ID_ANY, value="0", min=0, max=100, pos =(275, 510), size=wx.Size(60,-1))
        self.continueBttn= wx.Button(self, label = 'Continue', pos = (325,560))
        self.backBttn= wx.Button(self, label = 'Back', pos = (210,560))
        
class PanelFour(wx.Panel):
    
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        
        wx.Panel.__init__(self, parent=parent)   
        font = wx.Font(20, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        self.shippingInfo = wx.StaticText(self, label ='Shipping Information', pos =(180,220))
        self.shippingInfo.SetFont(font)
        delivfont = wx.Font(12, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = False, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        #self.delivLabel = wx.StaticText(self, label ='Delivery Type', pos =(185,290))
        #self.delivLabel.SetFont(delivfont)
        self.personalRadioBttn = wx.RadioButton(self, label = 'Personal Delivery', pos = (190, 290))
        self.uspsRadioBttn = wx.RadioButton(self, label = 'USPS', pos = (340, 290))
     
        
      


   

if __name__ == '__main__':
    
    app = wx.App()
    ex = MyForm()
    ex.Show()
    app.MainLoop()